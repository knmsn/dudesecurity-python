## Importando librarys

import socket
import os
import random
from urllib.request import urlopen
from ping3 import ping, verbose_ping
from bs4 import BeautifulSoup
from itertools import permutations
import requests 
import base64
from random import choice
import string

